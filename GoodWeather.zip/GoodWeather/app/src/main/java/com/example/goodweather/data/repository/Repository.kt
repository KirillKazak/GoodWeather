package com.example.goodweather.data.repository

interface Repository {
}