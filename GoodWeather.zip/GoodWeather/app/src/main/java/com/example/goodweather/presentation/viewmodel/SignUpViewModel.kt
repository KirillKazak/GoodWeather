package com.example.goodweather.presentation.viewmodel

import android.content.Context
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.navigation.findNavController
import com.example.goodweather.R
import com.example.goodweather.data.repository.RepositoryApp
import com.google.firebase.auth.FirebaseUser

class SignUpViewModel(private val context: Context) : ViewModel() {

    fun openLoginFragment (view: View) {
        view.setOnClickListener{
            view.findNavController().navigate(R.id.action_signUpFragment_to_loginFragment)
        }
    }

    fun checkUserAuthorization (currentUser : FirebaseUser) {
        if (currentUser != null) {
            Toast.makeText(context, "You already authorized", Toast.LENGTH_LONG).show()
        }
    }

    /*private fun сheckFields () {  //TODO rename where/what fields/what is check
       if (edtEmail.text == null) {
           Toast.makeText(context, "Enter you email", Toast.LENGTH_LONG).show()
       }
       if (edtPassword.text.length < 6) {
           Toast.makeText(context, "Your password is very short! Minimum number of characters: 6.", Toast.LENGTH_LONG).show()
       }
       if (edtPassword.text.length > 14) {
           Toast.makeText(context, "Your password is very long! Maximum number of characters: 14.", Toast.LENGTH_LONG).show()
       }
   }*/

    private fun firebaseAuthWithGoogle (idToken : String) {
        //val credential = GoogleAuthProvider.getCredential()
    }
}