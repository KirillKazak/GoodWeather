package com.example.goodweather.presentation.fragments

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.renderscript.ScriptGroup
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.Nullable
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.goodweather.R
import com.example.goodweather.data.repository.RepositoryApp
import com.example.goodweather.presentation.viewmodel.ProvideFactory
import com.example.goodweather.presentation.viewmodel.SignUpViewModel
import com.google.firebase.auth.FirebaseAuth

class SignUpFragment : Fragment() { //TODO rename fragment +

    lateinit var firebaseAuth: FirebaseAuth
    lateinit var viewModel : SignUpViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        @Nullable container: ViewGroup?,
        @Nullable savedInstanceState: Bundle?
    ): View? {
        val binding : ScriptGroup.Binding = DataBindingUtil.inflate(inflater, R.layout.fragment_signup, container, false)
        return binding.rootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val context : Context? = context
        val provideFactory = context?.let { ProvideFactory(it) }
        viewModel = ViewModelProvider(this, provideFactory!!).get(SignUpViewModel::class.java)
    }

    override fun onStart() {
        super.onStart()
//        firebaseAuth.currentUser?.let { viewModel.checkUserAuthorization(it) }
    }
}