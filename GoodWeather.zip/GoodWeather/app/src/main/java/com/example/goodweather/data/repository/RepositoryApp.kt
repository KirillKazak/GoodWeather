package com.example.goodweather.data.repository

class RepositoryApp : Repository {
}